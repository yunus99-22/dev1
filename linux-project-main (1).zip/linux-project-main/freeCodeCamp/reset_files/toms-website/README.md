I made this boilerplate
from the command line
for the freeCodeCamp bash lessons
